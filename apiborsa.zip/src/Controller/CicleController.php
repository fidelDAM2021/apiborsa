<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\JsonResponse;
use App\Entity\Cicle;
use Doctrine\Persistence\ManagerRegistry;
use FOS\RestBundle\Controller\Annotations as Rest;
use Symfony\Component\PasswordHasher\Hasher\UserPasswordHasherInterface;
use Symfony\Component\HttpFoundation\Request;
use App\Form\CicleType;


#[Route('api/cicle')]
class CicleController extends AbstractController
{
    #[Rest\Get('/', name: 'app_search_cycles')]
    public function searchCycles(ManagerRegistry $doctrine): JsonResponse {
        $rep=$doctrine->getRepository(Cicle::class);
        $cicles=$rep->findAll();
        $ciclesList=[];
        if(count($cicles) > 0) {
            foreach($cicles as $cicle) {
                $ciclesList[]=$cicle->toArray();
            }
            $response=[
                'ok'=>true,
                'cicles'=>$ciclesList,
            ];
        } 
        else {
            $response=[
                'ok'=>false,
                'error'=>'No hi ha cicles',
            ];
        }
        return new JsonResponse($response);
    }
    #[Rest\Get('/{value<\d+>}', name: 'app_searchbyid_cycle')]
    public function searchCicleById(ManagerRegistry $doctrine,$value=""): JsonResponse {
        $rep=$doctrine->getRepository(Cicle::class);
        $cicle=$rep->find($value);
        if($cicle) {
            $cicleArray=$cicle->toArray();
            $response=[
                'ok'=>true,
                'cicle'=>$cicleArray,
            ];
        }
        else {
            $response=[
                'ok'=>false,
                'error'=>'No existeix el cicle',
            ];
        }
        return new JsonResponse($response);
    }
    #[Rest\Post('/', name: 'app_new_cycle')]
    public function addNewcicle(ManagerRegistry $doctrine, Request
    $request): JsonResponse {
        try{
            $content=$request->getContent();
            $cicle=new Cicle();
            $cicle->fromJson($content);
            $entityManager=$doctrine->getManager();
            $entityManager->persist($cicle);
            $entityManager->flush();   
            $response=[
                'ok'=>true,
                'missatge'=>"S'ha inserit el cicle",
            ];
        }
        catch(Throwable $e) {
            $response=[
                'ok'=>false,
                'error'=>"Error en inserir el cicle",
            ];
        }
        return new JsonResponse($response);
    }
    #[Rest\Delete('/{id<\d+>}', name: 'app_delete_cycle')]
    public function deletecicle(ManagerRegistry $doctrine, $id=0): JsonResponse {
        $rep=$doctrine->getRepository(Cicle::class);
        $cicle=$rep->find($id);
        if($cicle) {
            $entityManager = $doctrine->getManager();
            $entityManager->remove($cicle);
            $entityManager->flush(); 
            $response=[
                'ok'=>true,
                'missatge'=>"S'ha eliminat el cicle",
            ];
        }
        else {
            $response=[
                'ok'=>false,
                'error'=>"El cicle no existeix",
            ];
        }
        return new JsonResponse($response);
    }
    #[Rest\Put('/{id<\d+>}', name: 'app_update_cycle')]
    public function updatecicle(ManagerRegistry $doctrine,Request
    $request, $id=0): Response {
        try{
        $content=$request->getContent();
        $rep=$doctrine->getRepository(Cicle::class);
        $cicle=$rep->find($id);
        if($cicle) {
            $cicle->fromJSON($content);
            $entityManager=$doctrine->getManager();
            $entityManager->flush();
            $response=[
                'ok'=>true,
                'missatge'=>"S'ha modificat el cicle",
            ];
        }
        else {
            $response=[
                'ok'=>false,
                'error'=>"No existeix el cicle",
            ];
        }
        }
        catch(Throwable $e) {
            $response=[
                'ok'=>false,
                'error'=>"Error en modificar el cicle",
            ];
        }
        return new JsonResponse($response);
    }
}
