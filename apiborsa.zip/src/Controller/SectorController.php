<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Routing\Annotation\Route;
use App\Entity\Sector;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Component\HttpFoundation\Request;
use App\Form\SectorType;
use FOS\RestBundle\Controller\Annotations as Rest;

#[Route('api/sector')]
class SectorController extends AbstractController
{
    #[Rest\Get('/', name: 'app_search_sectors')]
    public function searchSectors(ManagerRegistry $doctrine): JsonResponse {
        //$sectors=sectorList::getsectors();
        $rep=$doctrine->getRepository(Sector::class);
        $sectors=$rep->findAll();
        $sectorsList=[];
        if(count($sectors) > 0) {
            foreach($sectors as $sector) {
                $sectorsList[]=$sector->toArray();
            }
            $response=[
                'ok'=>true,
                'sectors'=>$sectorsList,
            ];
        } 
        else {
            $response=[
                'ok'=>false,
                'error'=>'No hi ha sectors',
            ];
        }
        return new JsonResponse($response);
    }
    #[Rest\Get('/{value<\d+>}/', name: 'app_searchbyid_sector')]
    public function searchsectorById(ManagerRegistry $doctrine,$value=""): JsonResponse {
        $rep=$doctrine->getRepository(Sector::class);
        $sector=$rep->find($value);
        if($sector) {
            $sectorArray=$sector->toArray();
            $response=[
                'ok'=>true,
                'sector'=>$sectorArray,
            ];
        }
        else {
            $response=[
                'ok'=>false,
                'error'=>'No existeix el sector',
            ];
        }
        return new JsonResponse($response);
    }
    #[Rest\Post('/', name: 'app_new_sector')]
    public function addNewsector(ManagerRegistry $doctrine, Request
    $request): JsonResponse {
        try{
            $content=$request->getContent();
            $sector=new Sector();
            $sector->fromJSON($content);
            $entityManager=$doctrine->getManager();
            $entityManager->persist($sector);
            $entityManager->flush();   
            $response=[
                'ok'=>true,
                'missatge'=>"S'ha inserit el sector",
            ];
        }
        catch(Throwable $e) {
            $response=[
                'ok'=>false,
                'error'=>"Error en inserir el sector",
            ];
        }
        return new JsonResponse($response);
    }
    #[Rest\Delete('/{id<\d+>}', name: 'app_delete_sector')]
    public function deletesector(ManagerRegistry $doctrine, $id=0): JsonResponse {
        $rep=$doctrine->getRepository(Sector::class);
        $sector=$rep->find($id);
        if($sector) {
            $entityManager = $doctrine->getManager();
            $entityManager->remove($sector);
            $entityManager->flush(); 
            $response=[
                'ok'=>true,
                'missatge'=>"S'ha eliminat el sector",
            ];
        }
        else {
            $response=[
                'ok'=>false,
                'error'=>"El sector no existeix",
            ];
        }
        return new JsonResponse($response);
    }
    #[Rest\Put('/{id<\d+>}', name: 'app_update_sector')]
    public function updatesector(ManagerRegistry $doctrine,Request
    $request, $id=0): Response {
        try{
            $content=$request->getContent();
            $rep=$doctrine->getRepository(Sector::class);
            $sector=$rep->find($id);
            if($sector) {
                $sector->fromJSON($content);
                $entityManager=$doctrine->getManager();
                $entityManager->flush();
                $response=[
                    'ok'=>true,
                    'missatge'=>"S'ha modificat el sector",
                ];
            }
            else {
                $response=[
                    'ok'=>false,
                    'error'=>"No existeix el sector",
                ];
            }
            }
            catch(Throwable $e) {
                $response=[
                    'ok'=>false,
                    'error'=>"Error en modificar el sector",
                ];
            }
            return new JsonResponse($response);
    }
}
