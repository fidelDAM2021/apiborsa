<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Routing\Annotation\Route;
use App\Entity\Empresa;
use App\Entity\Oferta;
use App\Entity\Cicle;
use Monolog\DateTimeImmutable;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Component\HttpFoundation\Request;
use FOS\RestBundle\Controller\Annotations as Rest;

#[Route('api/oferta')]
class OfertaController extends AbstractController
{
    #[Rest\Get('/', name: 'app_search_ofertes')]
    public function searchOfertes(ManagerRegistry $doctrine, Request $request): JsonResponse {
        //$cicles=cicleList::getcicles();
        $rep=$doctrine->getRepository(Oferta::class);
        $ofertes=$rep->findAll();
        $ofertesList=[];
        if(count($ofertes) > 0) {
            foreach($ofertes as $oferta) {
                $ofertesList[]=$oferta->toArray();
            }
            $response=[
                'ok'=>true,
                'ofertes'=>$ofertesList,
            ];
        } 
        else {
            $response=[
                'ok'=>false,
                'error'=>'No hi ha ofertes',
            ];
        }
        return new JsonResponse($response);
    }
    #[Rest\Get('/{value<\d+>}/', name: 'app_searchbyid_oferta')]
    public function searchContactById(ManagerRegistry $doctrine,$value=""): JsonResponse {
        $rep=$doctrine->getRepository(Oferta::class);
        $oferta=$rep->find($value);
        if($oferta) {
            $response=[
                'ok'=>true,
                'oferta'=>$oferta->toArray()
            ];
        }
        else {
            $response=[
                'ok'=>false,
                'error'=>"L'oferta no existeix"
            ];
        }
        return new JsonResponse($response);
    }
    #[Rest\Post('/', name: 'app_new_oferta')]
    public function addNewOferta(ManagerRegistry $doctrine, Request
    $request): JsonResponse {
        try{
            $content=$request->getContent();
            $oferta=new Oferta();
            $oferta->fromJSON($content);
            $rep=$doctrine->getRepository(Oferta::class);
            $repcicle=$doctrine->getRepository(Cicle::class);
            $repempresa=$doctrine->getRepository(Empresa::class);
            $wrongCicle=false;
            foreach($oferta->getCodisCicle() as $cicle) {
                $cicle=$repcicle->find($cicle);
                if($cicle) {
                    $oferta->addCicle($cicle);
                }
                else {
                    $wrongCicle=true;
                }
            }
            if($wrongCicle==false) {
                $empresa=$repempresa->find($oferta->getNif());
                if($empresa) {
                    $oferta->setNIFempresa($empresa);
                    $entityManager=$doctrine->getManager();
                    $entityManager->persist($oferta);
                    $entityManager->flush();   
                    $response=[
                        'ok'=>true,
                        'missatge'=>"S'ha inserit l'oferta",
                    ];
                }
                else {
                    $response=[
                        'ok'=>false,
                        'error'=>"No existeix l'empresa"
                    ];
                }
                
            }
            else {
                $response=[
                    'ok'=>false,
                    'error'=>"Hi ha cicles que no existeixen"
                ];
            }
        }
        catch(Throwable $e) {
            $response=[
                'ok'=>false,
                'error'=>"Error en inserir l'oferta",
            ];
        }
        return new JsonResponse($response);
       
    }
    #[Rest\Delete('/{id<\d+>}', name: 'app_delete_oferta')]
    public function deleteOferta(ManagerRegistry $doctrine, $id=0): JsonResponse {
        //return new Response("<h2>cicles by surname</h2>");
        $rep=$doctrine->getRepository(Oferta::class);
        $oferta=$rep->find($id);
        if($oferta) {
                $entityManager = $doctrine->getManager();
                $entityManager->remove($oferta);
                $entityManager->flush(); 
                $response = [
                    'ok'=>true,
                    'missatge'=>"S'ha eliminat l'oferta"
                ];
        }
        else {
            $response = [
                'ok'=>false,
                'error'=>"L'oferta no existeix"
            ];
        }
        return new JsonResponse($response);
    }
    #[Rest\Put('/{id<\d+>}', name: 'app_update_oferta')]
    public function updateOferta(ManagerRegistry $doctrine,Request
    $request, $id=0): JsonResponse {
        try{
            $content=$request->getContent();
            $rep=$doctrine->getRepository(Oferta::class);
            $oferta=$rep->find($id);
            if($oferta) {
                foreach($oferta->getCicle() as $cicle) {
                    $oferta->removeCicle($cicle);
                }
                $oferta->fromJSON($content);
                $repcicle=$doctrine->getRepository(Cicle::class);
                $repempresa=$doctrine->getRepository(Empresa::class);
                $wrongCicle=false;
                foreach($oferta->getCodisCicle() as $cicle) {
                    $cicle=$repcicle->find($cicle);
                    if($cicle) {
                        $oferta->addCicle($cicle);
                    }
                    else {
                        $wrongCicle=true;
                    }
                }
                if($wrongCicle==false) {
                    $empresa=$repempresa->find($oferta->getNif());
                    if($empresa) {
                        $oferta->setNIFempresa($empresa);
                        $entityManager=$doctrine->getManager();
                        $entityManager->persist($oferta);
                        $entityManager->flush();   
                        $response=[
                            'ok'=>true,
                            'missatge'=>"S'ha modificat l'oferta",
                        ];
                    }
                    else {
                        $response=[
                            'ok'=>false,
                            'error'=>"No existeix l'empresa"
                        ];
                    }
                }
                else {
                    $response=[
                        'ok'=>false,
                        'error'=>"Hi ha cicles que no existeixen"
                    ];
                }
            }
            else {
                $response=[
                    'ok'=>false,
                    'error'=>"L'oferta no existeix",
                ];
            }
            }
            catch(Throwable $e) {
                $response=[
                    'ok'=>false,
                    'error'=>"Error en modificar l'oferta",
                ];
            }
            return new JsonResponse($response);
    }
}
