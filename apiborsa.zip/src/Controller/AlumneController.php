<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Routing\Annotation\Route;
use App\Entity\Alumne;
use App\Entity\Curriculum;
use App\Entity\Cicle;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Component\HttpFoundation\Request;
use FOS\RestBundle\Controller\Annotations as Rest;

#[Route('api/alumne')]
class AlumneController extends AbstractController
{
    #[Rest\Get('/', name: 'app_search_students')]
    public function searchStudents(ManagerRegistry $doctrine): JsonResponse {
        $rep=$doctrine->getRepository(Alumne::class);
        $alumnes=$rep->findAll();
        $alumnesList=[];
        if(count($alumnes) > 0) {
            foreach($alumnes as $alumne) {
                $alumnesList[]=$alumne->toArray();
            }
            $response=[
                'ok'=>true,
                'alumnes'=>$alumnesList,
            ];
        } 
        else {
            $response=[
                'ok'=>false,
                'error'=>'No hi ha alumnes',
            ];
        }
        return new JsonResponse($response);
    }
    #[Rest\Get('/{value<\d+>}/', name: 'app_searchbyid_student')]
    public function searchStudentById(ManagerRegistry $doctrine,$value=""): JsonResponse {
        $rep=$doctrine->getRepository(Alumne::class);
        $alumne=$rep->find($value);
        if($alumne) {
            $alumneArray=$alumne->toArray();
            $response=[
                'ok'=>true,
                'alumne'=>$alumneArray,
            ];
        }
        else {
            $response=[
                'ok'=>false,
                'error'=>"No existeix l'alumne",
            ];
        }
        return new JsonResponse($response);
    }
    #[Rest\Post('/', name: 'app_new_student')]
    public function addNewalumne(ManagerRegistry $doctrine, Request
    $request): JsonResponse {
        try{
            $content=$request->getContent();
            $alumne=new Alumne();
            $alumne->fromJSON($content);
            $rep=$doctrine->getRepository(Alumne::class);
            $repcicle=$doctrine->getRepository(Cicle::class);
            $wrongCicle=false;
            foreach($alumne->getCodisCicle() as $cicle) {
                $cicle=$repcicle->find($cicle);
                if($cicle) {
                    $alumne->addCicle($cicle);
                }
                else {
                    $wrongCicle=true;
                }
            }
            if($wrongCicle==false) {
                $curr=new Curriculum();
                $curr->setExperiencia($alumne->getDadesCurriculum()['experiencia']);
                $curr->setIdiomes($alumne->getDadesCurriculum()['idiomes']);
                $curr->setEstudis($alumne->getDadesCurriculum()['estudis']);
                $curr->setCompetencies($alumne->getDadesCurriculum()['competencies']);
                $alumne->setCurriculum($curr);
                $entityManager=$doctrine->getManager();
                $entityManager->persist($alumne);
                $entityManager->flush();   
                $response=[
                    'ok'=>true,
                    'missatge'=>"S'ha inserit l'alumne",
                ];
            }
            else {
                $response=[
                    'ok'=>false,
                    'error'=>"Hi ha cicles que no existeixen"
                ];
            }
        }
        catch(Throwable $e) {
            $response=[
                'ok'=>false,
                'error'=>"Error en inserir l'alumne",
            ];
        }
        return new JsonResponse($response);
    }
    #[Rest\Delete('/{id<\d+>}', name: 'app_delete_student')]
    public function deletealumne(ManagerRegistry $doctrine, $id=0): JsonResponse {
        //return new Response("<h2>cicles by surname</h2>");
        $rep=$doctrine->getRepository(Alumne::class);
        $alumne=$rep->find($id);
        if($alumne) {
            $entityManager = $doctrine->getManager();
            $entityManager->remove($alumne);
            $entityManager->flush(); 
            $response=[
                'ok'=>true,
                'missatge'=>"S'ha eliminat l'alumne",
            ];
        }
        else {
            $response=[
                'ok'=>false,
                'error'=>"L'alumne no existeix",
            ];
        }
        return new JsonResponse($response);
    }
    #[Rest\Put('/{id<\d+>}', name: 'app_update_student')]
    public function updatealumne(ManagerRegistry $doctrine,Request
    $request, $id=0): JsonResponse {
        try{
            $content=$request->getContent();
            $rep=$doctrine->getRepository(Alumne::class);
            $alumne=$rep->find($id);
            if($alumne) {
                foreach($alumne->getCicle() as $cicle) {
                    $alumne->removeCicle($cicle);
                }
                $alumne->fromJSON($content);
                $repcicle=$doctrine->getRepository(Cicle::class);
                $wrongCicle=false;
                foreach($alumne->getCodisCicle() as $cicle) {
                    $cicle=$repcicle->find($cicle);
                    if($cicle) {
                        $alumne->addCicle($cicle);
                    }
                    else {
                        $wrongCicle=true;
                    }
                }
                if($wrongCicle==false) {
                    $curr=$alumne->getCurriculum();
                    $curr->setExperiencia($alumne->getDadesCurriculum()['experiencia']);
                    $curr->setIdiomes($alumne->getDadesCurriculum()['idiomes']);
                    $curr->setEstudis($alumne->getDadesCurriculum()['estudis']);
                    $curr->setCompetencies($alumne->getDadesCurriculum()['competencies']);
                    $alumne->setCurriculum($curr);
                    $entityManager=$doctrine->getManager();
                    $entityManager->persist($alumne);
                    $entityManager->flush();   
                    $response=[
                        'ok'=>true,
                        'missatge'=>"S'ha modificat l'alumne",
                    ];
                }
                else {
                    $response=[
                        'ok'=>false,
                        'error'=>"Hi ha cicles que no existeixen"
                    ];
                }
            }
            else {
                $response=[
                    'ok'=>false,
                    'error'=>"L'alumne no existeix",
                ];
            }
            }
            catch(Throwable $e) {
                $response=[
                    'ok'=>false,
                    'error'=>"Error en modificar l'alumne",
                ];
            }
            return new JsonResponse($response);
    }
    /*
    #[Rest\Post('/curriculum/{id<\d+>}', name: 'app_curriculum_student')]
    public function curriculumalumne(ManagerRegistry $doctrine,Request
    $request, $id=0): JsonResponse {
        $repAl=$doctrine->getRepository(Alumne::class);
        $alumne=$repAl->find($id);
        $repCu=$doctrine->getRepository(Curriculum::class);
        $curriculum=$repCu->findOneBy(["alumne"=>$id]);
        if($curriculum==null) {
            $curriculum=new Curriculum();
            $curriculum->setAlumne($alumne);
        }
        $form=$this->createForm(CurriculumType::class, $curriculum);
        $form->handleRequest($request);
        if($form->isSubmitted() && $form->isValid()) {
            if($form->getClickedButton()->getName()==="Guardar"){ 
                $curriculum=$form->getData();
                $pdf=$form->get('pdf')->getData();
                if($pdf) {
                    $newFileName=$id.".pdf";
                    $pdf->move(
                            $this->getParameter('curriculums_directory'),
                            $newFileName
                        );
                    $alumne->setPDF(true);
                }
                $entityManager=$doctrine->getManager();
                $entityManager->persist($curriculum);
                $entityManager->flush();
            }
            return $this->redirectToRoute("app_search_students");
        }
        return $this->render('alumne/curriculumform.html.twig', array(
            'form' => $form->createView(),
            'title' => "Editar currículum",
            'hasPDF' => $alumne->isPDF(),
            'idAlumne'=>$id));
    }
    #[Route('/alumne/download/{id}', name: 'app_download_student')]
    public function downloadAction($id) {
        $downloadedFile = $this->getParameter('curriculums_directory')."\/".$id.".pdf";
        $response = new Response();
        $response->headers->set('Content-type', 'application/octet-stream');
        $response->headers->set('Content-Disposition', sprintf('attachment; filename="%s"',$downloadedFile));
        $response->setContent(file_get_contents($downloadedFile));
        $response->setStatusCode(200);
        $response->headers->set('Content-Transfer-Encoding', 'binary');
        $response->headers->set('Pragma', 'no-cache');
        $response->headers->set('Expires', '0');
        return $response;
    }
    */
}
