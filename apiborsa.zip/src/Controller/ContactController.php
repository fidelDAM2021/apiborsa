<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Routing\Annotation\Route;
use App\Entity\Contacte;
use App\Entity\Empresa;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Component\HttpFoundation\Request;
use FOS\RestBundle\Controller\Annotations as Rest;

#[Route('api/contacte')]
class ContactController extends AbstractController
{
    #[Rest\Get('/', name: 'app_search_contacts')]
    public function searchContacts(ManagerRegistry $doctrine, Request $request): JsonResponse {
        $rep=$doctrine->getRepository(Contacte::class);
        $contactes=$rep->findAll();
        $contactesList=[];
        if(count($contactes) > 0) {
            foreach($contactes as $contacte) {
                $contactesList[]=$contacte->toArray();
            }
            $response=[
                'ok'=>true,
                'contactes'=>$contactesList,
            ];
        } 
        else {
            $response=[
                'ok'=>false,
                'error'=>'No hi ha contactes',
            ];
        }
        return new JsonResponse($response);
    }
    #[Rest\Get('/{value<\d+>}/', name: 'app_searchbyid_contact')]
    public function searchContactById(ManagerRegistry $doctrine,$value=""): Response {
        $rep=$doctrine->getRepository(Contacte::class);
        $contacte=$rep->find($value);
        if($contacte) {
            $contacteArray=$contacte->toArray();
            $response=[
                'ok'=>true,
                'contacte'=>$contacteArray,
            ];
        }
        else {
            $response=[
                'ok'=>false,
                'error'=>"No existeix el contacte",
            ];
        }
        return new JsonResponse($response);
    }
    #[Rest\Post('/', name: 'app_new_contact')]
    public function addNewContact(ManagerRegistry $doctrine, Request
    $request): JsonResponse {
        try{
            $content=$request->getContent();
            $contacte=new Contacte();
            $contacte->fromJson($content);
            $rep=$doctrine->getRepository(Empresa::class);
            $empresa=$rep->find($contacte->getNif());
            if($empresa) {
                $contacte->setNIFempresa($empresa);
                $entityManager=$doctrine->getManager();
                $entityManager->persist($contacte);
                $entityManager->flush();   
                $response=[
                    'ok'=>true,
                    'missatge'=>"S'ha inserit el contacte",
                ];
            }
            else {
                $response=[
                    'ok'=>false,
                    'error'=>"No existeix l'empresa"
                ];
            }
        }
        catch(\Throwable $e) {
            $response=[
                'ok'=>false,
                'error'=>"Error en inserir el contacte",
            ];
        }
        return new JsonResponse($response);
    }
    #[Rest\Delete('/{id<\d+>}', name: 'app_delete_contact')]
    public function deleteContact(ManagerRegistry $doctrine, $id=0): JsonResponse {
        $rep=$doctrine->getRepository(Contacte::class);
        $contacte=$rep->find($id);
        if($contacte) {
            $entityManager = $doctrine->getManager();
            $entityManager->remove($contacte);
            $entityManager->flush(); 
            $response=[
                'ok'=>true,
                'missatge'=>"S'ha eliminat el contacte",
            ];
        }
        else {
            $response=[
                'ok'=>false,
                'error'=>"El contacte no existeix",
            ];
        }
        return new JsonResponse($response);
    }
    #[Rest\Put('/{id<\d+>}', name: 'app_update_contact')]
    public function updateContact(ManagerRegistry $doctrine,Request
    $request, $id=0): JsonResponse {
        try{
            $content=$request->getContent();
            $rep=$doctrine->getRepository(Contacte::class);
            $repempresa=$doctrine->getRepository(Empresa::class);
            $contacte=$rep->find($id);
            if($contacte) {
                $contacte->fromJson($content);
                $empresa=$repempresa->find($contacte->getNif());
                if($empresa) {
                    $contacte->setNIFEmpresa($empresa);
                    $entityManager=$doctrine->getManager();
                    $entityManager->persist($contacte);
                    $entityManager->flush();   
                    $response=[
                       'ok'=>true,
                      'missatge'=>"S'ha modificat el contacte",
                 ];
                }
                else {
                  $response=[
                    'ok'=>false,
                    'error'=>"No existeix l'empresa"
                ];
                }
            }
            else {
                $response=[
                  'ok'=>false,
                  'error'=>"No existeix el contacte"
                ];
            }
           
        }
        catch(\Throwable $e) {
            $response=[
                'ok'=>false,
                'error'=>"Error modificant el contacte"
            ];
        }
        return new JsonResponse($response);
    }    
}
